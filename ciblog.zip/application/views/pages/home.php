<h3><?= $title ?></h3>
<p>Welcome to CI_blog application</p>
