<h3><?= $title ?></h3>
<p>This is CI_blog verison 1.0</p>
